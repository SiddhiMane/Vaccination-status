# Vaccination-Status


This is Vaccination-Status Project which uses following technologies :-
    1. HTML
    2. CSS
    3.Python


Before running this please make ensure that you have proper version of python and thier extensions..


Extensions of python needed are :- 
    1. Flak 
    2. Pandas


To install flask extensions use following commands (Do on cmd) :-
    1. pip install flask 
    2. pip insatll flask-ngrok
    3. pip install flask-bootstrap


To install pandas extension use following command (on cmd) :-
      pip install pandas
